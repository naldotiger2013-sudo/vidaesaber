// ==============================================
// 🎵 SISTEMA DE ÁUDIO E MÚSICAS
// ==============================================

// Configurações de volume
const MUSICA_VOLUME_INTRO = 0.4;
const MUSICA_VOLUME_JOGO = 0.3;
const MUSICA_TRANSICAO = 1800;

// Banco de músicas organizado por local e versão
const BANCO_MUSICAS = {
  introducao: "audios/introducao.mp3",
  cidade: {
    v1: "audios/cidade_v1.mp3",
    v2: "audios/cidade_v2.mp3",
    v3: "audios/cidade_v3.mp3",
    v4: "audios/cidade_v4.mp3",
    v5: "audios/cidade_v5.mp3"
  },
  floresta: {
    v1: "audios/floresta_v1.mp3",
    v2: "audios/floresta_v2.mp3",
    v3: "audios/floresta_v3.mp3",
    v4: "audios/floresta_v4.mp3",
    v5: "audios/floresta_v5.mp3"
  },
  biblioteca: {
    v1: "audios/biblioteca_v1.mp3",
    v2: "audios/biblioteca_v2.mp3",
    v3: "audios/biblioteca_v3.mp3",
    v4: "audios/biblioteca_v4.mp3",
    v5: "audios/biblioteca_v5.mp3"
  },
  caverna: {
    v1: "audios/caverna_v1.mp3",
    v2: "audios/caverna_v2.mp3",
    v3: "audios/caverna_v3.mp3",
    v4: "audios/caverna_v4.mp3",
    v5: "audios/caverna_v5.mp3"
  }
};

let musicaAtual = null;
let localAtual = "";
let versaoAtual = "";

// ==============================================
// FUNÇÕES DE CONTROLE DE ÁUDIO
// ==============================================
function tocarIntroducao() {
  pararMusicaAtual();
  musicaAtual = new Audio(BANCO_MUSICAS.introducao);
  musicaAtual.volume = MUSICA_VOLUME_INTRO;
  musicaAtual.loop = true;
  musicaAtual.play().catch(() => console.log("Clique na tela para ativar o som."));
}

function pararMusicaAtual() {
  return new Promise(resolver => {
    if (!musicaAtual) return resolver();
    let volume = musicaAtual.volume;
    const diminuir = setInterval(() => {
      if (volume > 0.05) {
        volume -= 0.04;
        musicaAtual.volume = volume;
      } else {
        musicaAtual.pause();
        musicaAtual = null;
        clearInterval(diminuir);
        resolver();
      }
    }, MUSICA_TRANSICAO / 25);
  });
}

function obterVersaoMusica(sabedoria) {
  if (sabedoria <= 100) return "v1";
  if (sabedoria <= 300) return "v2";
  if (sabedoria <= 500) return "v3";
  const grupo = Math.floor((sabedoria - 501) / 500) + 4;
  return `v${grupo}`;
}

async function trocarMusica(novoLocal) {
  const novaVersao = obterVersaoMusica(jogador.sabedoria);
  if (novoLocal === localAtual && novaVersao === versaoAtual) return;
  await pararMusicaAtual();
  const caminho = BANCO_MUSICAS[novoLocal]?.[novaVersao];
  if (!caminho) return;
  musicaAtual = new Audio(caminho);
  musicaAtual.volume = 0;
  musicaAtual.loop = true;
  musicaAtual.play().catch(e => console.log("Arquivo de áudio não encontrado:", e));
  let volumeAtual = 0;
  const aumentar = setInterval(() => {
    if (volumeAtual < MUSICA_VOLUME_JOGO) {
      volumeAtual += 0.04;
      musicaAtual.volume = volumeAtual;
    } else clearInterval(aumentar);
  }, MUSICA_TRANSICAO / 25);
  localAtual = novoLocal;
  versaoAtual = novaVersao;
}

function verificarMusica() {
  let local = "cidade";
  if (regiaoAtual === "floresta_1") local = "floresta";
  if (regiaoAtual === "biblioteca") local = "biblioteca";
  if (regiaoAtual === "caverna_1") local = "caverna";
  trocarMusica(local);
}
