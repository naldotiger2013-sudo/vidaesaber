// ==============================================
// 🧍 DADOS DO JOGADOR, DINHEIRO E SALVAMENTO
// ==============================================

const VERSAO_JOGO = "1.3.3";

// Dados completos do personagem
let jogador = {
  versao: VERSAO_JOGO,
  nivel: 1,
  nomeNivel: "Infantil",
  sabedoria: 0,
  energia: 100,
  energiaMax: 100,
  vida: 100,
  vidaMax: 100,
  // 💰 Sistema de Dinheiro em Real
  dinheiro: 0,
  x: 1200,
  y: 1200,
  angulo: 0,
  inventario: { 
    espacoMax: 15, 
    itens: [] 
  },
  livrosAprendidos: [],
  regioesLiberadas: ["principal"],
  missoesConcluidas: []
};

// ==============================================
// 💰 FUNÇÕES DE DINHEIRO
// ==============================================
function ganharDinheiro(valor) {
  if (valor > 0) {
    jogador.dinheiro += valor;
    console.log(`Ganhou R$ ${valor.toFixed(2)}`);
    atualizarHUD(); // Atualiza o valor na tela
  }
}

function gastarDinheiro(valor) {
  if (valor > 0 && jogador.dinheiro >= valor) {
    jogador.dinheiro -= valor;
    console.log(`Gastou R$ ${valor.toFixed(2)}`);
    atualizarHUD(); // Atualiza o valor na tela
    return true;
  } else {
    alert("❌ Dinheiro insuficiente!");
    return false;
  }
}

// ==============================================
// 💾 SISTEMA DE SALVAMENTO SEGURO
// ==============================================
function salvarJogo() {
  const dadosParaSalvar = {
    versao: VERSAO_JOGO,
    dados: jogador,
    regiaoAtual: regiaoAtual || "principal",
    portalVisivel: portalVisivel || false
  };
  
  localStorage.setItem("vida_e_saber_save", JSON.stringify(dadosParaSalvar));
  alert("✅ Progresso salvo com sucesso!");
}

function carregarJogo() {
  const salvo = localStorage.getItem("vida_e_saber_save");
  
  if (!salvo) {
    alert("ℹ️ Nenhum jogo salvo encontrado.");
    return false;
  }

  try {
    const dadosSalvos = JSON.parse(salvo);
    
    // Mantém a estrutura atual mesmo se houver dados antigos
    jogador = { 
      ...jogador, 
      ...dadosSalvos.dados, 
      versao: VERSAO_JOGO 
    };
    
    regiaoAtual = dadosSalvos.regiaoAtual || "principal";
    portalVisivel = dadosSalvos.portalVisivel || false;
    
    alert("✅ Progresso carregado!");
    return true;
  } catch (erro) {
    console.error("Erro ao carregar:", erro);
    alert("❌ Arquivo de salvamento corrompido.");
    return false;
  }
}
