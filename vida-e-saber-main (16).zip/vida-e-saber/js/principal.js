// ==============================================
// 🚀 ARQUIVO PRINCIPAL - LIGA TODOS OS SISTEMAS
// ==============================================

// Elementos da interface
const telaInicial = document.getElementById("tela-inicial");
const telaJogo = document.getElementById("tela-jogo");
const canvas = document.getElementById("canvas-jogo");
const ctx = canvas.getContext("2d");
const telaPerfil = document.getElementById("tela-perfil");
const telaInventario = document.getElementById("tela-inventario");
const menuPrincipal = document.getElementById("menu-principal");

let loopAtivo = false;

// ==============================================
// ATUALIZAR INFORMAÇÕES NA TELA (HUD)
// ==============================================
function atualizarHUD() {
  // Atualiza valores principais
  document.getElementById("valor-sabedoria").textContent = `${jogador.sabedoria} / 100`;
  document.getElementById("barra-sabedoria").style.width = `${Math.min(jogador.sabedoria, 100)}%`;

  document.getElementById("valor-energia").textContent = `${jogador.energia} / ${jogador.energiaMax}`;
  document.getElementById("barra-energia").style.width = `${(jogador.energia / jogador.energiaMax) * 100}%`;

  document.getElementById("valor-vida").textContent = `${jogador.vida} / ${jogador.vidaMax}`;
  document.getElementById("barra-vida").style.width = `${(jogador.vida / jogador.vidaMax) * 100}%`;

  document.getElementById("valor-dinheiro").textContent = `R$ ${jogador.dinheiro.toFixed(2).replace('.', ',')}`;
  document.getElementById("nivel-atual").textContent = `${jogador.nivel} - ${jogador.nomeNivel}`;

  // Atualiza telas de perfil/inventário se estiverem abertas
  if (!telaPerfil.classList.contains("escondido")) {
    document.getElementById("perfil-nivel").textContent = `${jogador.nivel} - ${jogador.nomeNivel}`;
    document.getElementById("perfil-sabedoria").textContent = `${jogador.sabedoria} / 100`;
    document.getElementById("perfil-energia").textContent = `${jogador.energia} / ${jogador.energiaMax}`;
    document.getElementById("perfil-vida").textContent = `${jogador.vida} / ${jogador.vidaMax}`;
    document.getElementById("perfil-dinheiro").textContent = `R$ ${jogador.dinheiro.toFixed(2).replace('.', ',')}`;
  }
}

// ==============================================
// SISTEMA DE INTERAÇÃO COM OBJETOS
// ==============================================
function verificarInteracao() {
  const blocoX = Math.floor(jogador.x / TAMANHO_BLOCO);
  const blocoY = Math.floor(jogador.y / TAMANHO_BLOCO);
  const tipo = mapa[blocoY]?.[blocoX];

  // Interagir com livro
  if (tipo === TIPOS.LIVRO) {
    const livro = BANCO_LIVROS.find(l => !jogador.livrosAprendidos.includes(l.id));
    if (livro) {
      const ler = confirm(`📚 ${livro.titulo}\n\n${livro.texto.substring(0, 150)}...\n\nDeseja ler este livro?`);
      if (ler) {
        jogador.livrosAprendidos.push(livro.id);
        jogador.sabedoria += livro.sabedoriaGanha;
        alert(`✅ ${livro.mensagemFinal}\n\n+${livro.sabedoriaGanha} pontos de sabedoria!`);
        atualizarHUD();
        gerarMapaRegiao(); // Atualiza mapa (ex: libera portal)
        verificarMusica();
      }
    }
  }

  // Interagir com portal
  if (tipo === TIPOS.PORTAL) {
    const usar = confirm("🌀 Você encontrou um portal!\n\nDeseja atravessar para uma nova região?");
    if (usar) entrarPortal();
  }
}

// ==============================================
// DESENHAR JOGADOR NA TELA
// ==============================================
function desenharJogador() {
  const deslocamentoX = jogador.x - canvas.width / 2;
  const deslocamentoY = jogador.y - canvas.height / 2;

  ctx.fillStyle = "#FFD700";
  ctx.beginPath();
  ctx.arc(
    canvas.width / 2,
    canvas.height / 2,
    TAMANHO_BLOCO / 2.2,
    0,
    Math.PI * 2
  );
  ctx.fill();
  ctx.strokeStyle = "#000";
  ctx.lineWidth = 1.5;
  ctx.stroke();
}

// ==============================================
// LOOP PRINCIPAL DO JOGO
// ==============================================
function loopJogo() {
  if (!loopAtivo) return;

  desenharMapa();
  atualizarMovimento();
  desenharJogador();
  atualizarHUD();

  requestAnimationFrame(loopJogo);
}

// ==============================================
// INICIALIZAR TODOS OS EVENTOS
// ==============================================
function inicializarJogo() {
  // Botões da tela inicial
  document.getElementById("btn-novo").addEventListener("click", () => {
    // Reseta dados para novo jogo
    jogador = {
      versao: VERSAO_JOGO,
      nivel: 1,
      nomeNivel: "Infantil",
      sabedoria: 0,
      energia: 100,
      energiaMax: 100,
      vida: 100,
      vidaMax: 100,
      dinheiro: 0,
      x: 12 * TAMANHO_BLOCO,
      y: 12 * TAMANHO_BLOCO,
      angulo: 0,
      inventario: { espacoMax: 15, itens: [] },
      livrosAprendidos: [],
      regioesLiberadas: [REGIOES.PRINCIPAL],
      missoesConcluidas: []
    };
    regiaoAtual = REGIOES.PRINCIPAL;
    portalVisivel = false;

    gerarMapaRegiao();
    telaInicial.classList.add("escondido");
    telaJogo.classList.remove("escondido");
    tocarIntroducao();
    loopAtivo = true;
    loopJogo();
  });

  document.getElementById("btn-continuar").addEventListener("click", () => {
    if (carregarJogo()) {
      gerarMapaRegiao();
      telaInicial.classList.add("escondido");
      telaJogo.classList.remove("escondido");
      verificarMusica();
      loopAtivo = true;
      loopJogo();
    }
  });

  // Botões do jogo
  document.getElementById("botao-menu").addEventListener("click", () => {
    menuPrincipal.classList.remove("escondido");
  });

  document.getElementById("opcao-salvar").addEventListener("click", salvarJogo);
  document.getElementById("opcao-fechar-menu").addEventListener("click", () => {
    menuPrincipal.classList.add("escondido");
  });

  document.getElementById("acao-amarela").addEventListener("click", verificarInteracao);

  inicializarControles();
}

// Inicia tudo quando a página carrega
window.addEventListener("load", inicializarJogo);
