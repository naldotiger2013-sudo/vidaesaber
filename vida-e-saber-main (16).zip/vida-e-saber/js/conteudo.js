// ==============================================
// 📚 CONTEÚDO DO JOGO: LIVROS, REGIÕES E ITENS
// ==============================================

// Configurações gerais
const SABEDORIA_PARA_PORTAL = 40;

// Tipos de terreno/objetos do mapa
const TIPOS = {
  GRAMA: 1,
  ASFALTO: 2,
  CALCADA: 3,
  PAREDE: 4,
  ESCADA: 5,
  LIVRO: 6,
  AGUA: 7,
  PORTAL: 8
};

// Definição das regiões/mundos
const REGIOES = {
  PRINCIPAL: "principal",
  FLORESTA_1: "floresta_1",
  BIBLIOTECA: "biblioteca",
  CAVERNA_1: "caverna_1"
};

// Banco de livros educativos
const BANCO_LIVROS = [
  {
    id: 1,
    titulo: "Matemática: O que é a Adição?",
    area: "Matemática",
    nivel: "Infantil / Fundamental I",
    texto: `
A adição é uma das operações mais importantes da matemática. Ela serve para **juntar quantidades** e descobrir o total.

🔢 Como funciona:
Quando temos dois ou mais números e queremos saber quanto vale todos juntos, usamos a adição.
Exemplo: Se você tem 2 laranjas e ganha mais 3, quantas tem no total?
2 + 3 = 5 → O resultado é 5!

💡 Para que serve na vida real?
- Para contar dinheiro
- Para saber quantos ingredientes usar na cozinha
- Para calcular distâncias
- Para organizar objetos

A adição é a base para aprender outros cálculos mais avançados no futuro!
    `,
    sabedoriaGanha: 20,
    mensagemFinal: "Esse conhecimento vai te ajudar a resolver problemas do dia a dia!"
  },
  {
    id: 2,
    titulo: "Língua Portuguesa: A Importância das Palavras",
    area: "Língua Portuguesa",
    nivel: "Infantil / Fundamental I",
    texto: `
As palavras são como ferramentas: usadas da forma certa, ajudam a nos entender e a entender o mundo.

📝 O que aprendemos:
- Cada palavra tem um significado
- Juntando palavras, formamos frases
- Comunicar bem evita mal-entendidos

✨ Na prática:
Saber falar e escrever corretamente ajuda na escola, no trabalho e em todas as relações com as pessoas.

Quanto mais palavras você conhece, melhor consegue expressar o que pensa e sente!
    `,
    sabedoriaGanha: 20,
    mensagemFinal: "Uma boa comunicação abre muitas portas na vida!"
  }
];

// Banco de itens e loja (para usar com o sistema de dinheiro)
const LOJA_ITENS = [
  {
    id: 1,
    nome: "Mochila Pequena",
    descricao: "Aumenta o espaço do inventário em +5",
    preco: 30.00,
    efeito: "espaco"
  },
  {
    id: 2,
    nome: "Água Potável",
    descricao: "Recupera 20 de energia",
    preco: 5.00,
    efeito: "energia"
  },
  {
    id: 3,
    nome: "Remédio Simples",
    descricao: "Recupera 30 de vida",
    preco: 12.00,
    efeito: "vida"
  }
];
