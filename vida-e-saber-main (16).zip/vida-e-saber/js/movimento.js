// ==============================================
// 🎮 CONTROLES E MOVIMENTO DO PERSONAGEM
// ==============================================

// Configurações de velocidade
const VELOCIDADE_MOVIMENTO = 2.5;

// Estado das teclas e botões
let teclas = {
  cima: false,
  baixo: false,
  esquerda: false,
  direita: false
};

// ==============================================
// CONFIGURAR BOTÕES DA TELA
// ==============================================
function configurarBotao(idBotao, nomeAcao) {
  const botao = document.getElementById(idBotao);
  if (!botao) return;

  // Ativar ação ao pressionar
  const ativar = (e) => {
    e.preventDefault();
    teclas[nomeAcao] = true;
  };

  // Desativar ação ao soltar
  const desativar = () => {
    teclas[nomeAcao] = false;
  };

  // Eventos para computador e celular/toque
  botao.addEventListener("touchstart", ativar);
  botao.addEventListener("mousedown", ativar);
  
  botao.addEventListener("touchend", desativar);
  botao.addEventListener("touchcancel", desativar);
  botao.addEventListener("mouseup", desativar);
  botao.addEventListener("mouseout", desativar);
}

// ==============================================
// INICIALIZAR TODOS OS CONTROLES
// ==============================================
function inicializarControles() {
  // Controles do TECLADO
  document.addEventListener('keydown', (e) => {
    switch(e.key) {
      case 'ArrowUp':
        teclas.cima = true;
        e.preventDefault();
        break;
      case 'ArrowDown':
        teclas.baixo = true;
        e.preventDefault();
        break;
      case 'ArrowLeft':
        teclas.esquerda = true;
        e.preventDefault();
        break;
      case 'ArrowRight':
        teclas.direita = true;
        e.preventDefault();
        break;
    }
  });

  document.addEventListener('keyup', (e) => {
    switch(e.key) {
      case 'ArrowUp': teclas.cima = false; break;
      case 'ArrowDown': teclas.baixo = false; break;
      case 'ArrowLeft': teclas.esquerda = false; break;
      case 'ArrowRight': teclas.direita = false; break;
    }
  });

  // Ligar botões da tela no padrão que funcionou antes
  configurarBotao("btn-cima", "cima");
  configurarBotao("btn-baixo", "baixo");
  configurarBotao("btn-esquerda", "esquerda");
  configurarBotao("btn-direita", "direita");
}

// ==============================================
// ATUALIZAR MOVIMENTO COM COLISÃO
// ==============================================
function atualizarMovimento() {
  let novoX = jogador.x;
  let novoY = jogador.y;

  // Calcula nova posição
  if (teclas.cima) novoY -= VELOCIDADE_MOVIMENTO;
  if (teclas.baixo) novoY += VELOCIDADE_MOVIMENTO;
  if (teclas.esquerda) novoX -= VELOCIDADE_MOVIMENTO;
  if (teclas.direita) novoX += VELOCIDADE_MOVIMENTO;

  // Verifica colisão antes de permitir o movimento
  const meio = TAMANHO_BLOCO / 2;
  if (!ehParede(novoX, novoY) && 
      !ehParede(novoX + meio, novoY) &&
      !ehParede(novoX, novoY + meio) &&
      !ehParede(novoX + meio, novoY + meio)) {
    jogador.x = novoX;
    jogador.y = novoY;
  }
}
