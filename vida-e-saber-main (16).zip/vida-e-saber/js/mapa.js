// ==============================================
// 🗺️ MAPAS, CENÁRIOS E COLISÃO
// ==============================================

// Configurações do tamanho do mapa
const TAMANHO_BLOCO = 24;
const CONFIG_MAPA = {
  atual: { largura: 100, altura: 100 }
};

// Variáveis globais do mapa
let regiaoAtual = REGIOES.PRINCIPAL;
let mapa = [];
let portalVisivel = false;

// ==============================================
// GERAR MAPA DE ACORDO COM A REGIÃO
// ==============================================
function gerarMapaRegiao() {
  const largura = CONFIG_MAPA.atual.largura;
  const altura = CONFIG_MAPA.atual.altura;
  
  // Cria mapa todo de grama por padrão
  mapa = Array(altura).fill().map(() => Array(largura).fill(TIPOS.GRAMA));

  // Borda de parede em todo o contorno
  for (let x = 0; x < largura; x++) {
    mapa[0][x] = TIPOS.PAREDE;
    mapa[altura - 1][x] = TIPOS.PAREDE;
  }
  for (let y = 0; y < altura; y++) {
    mapa[y][0] = TIPOS.PAREDE;
    mapa[y][largura - 1] = TIPOS.PAREDE;
  }

  // Conteúdo específico de cada região
  switch(regiaoAtual) {
    case REGIOES.PRINCIPAL:
      // Rua principal
      for (let x = 10; x < largura - 10; x++) {
        mapa[Math.floor(altura/2)][x] = TIPOS.ASFALTO;
        mapa[Math.floor(altura/2)-1][x] = TIPOS.CALCADA;
        mapa[Math.floor(altura/2)+1][x] = TIPOS.CALCADA;
      }
      // Portal aparece quando tiver sabedoria suficiente
      if (portalVisivel || jogador.sabedoria >= SABEDORIA_PARA_PORTAL) {
        mapa[15][Math.floor(largura/2)] = TIPOS.PORTAL;
        portalVisivel = true;
      }
      // Livros espalhados
      mapa[20][15] = TIPOS.LIVRO;
      mapa[50][largura-20] = TIPOS.LIVRO;
      mapa[35][45] = TIPOS.LIVRO;
      mapa[60][65] = TIPOS.LIVRO;
      break;

    case REGIOES.FLORESTA_1:
      // Floresta com árvores e água
      for (let y = 10; y < altura-10; y++) {
        for (let x = 10; x < largura-10; x++) {
          if (Math.random() < 0.12) mapa[y][x] = TIPOS.PAREDE;
          if (Math.random() < 0.05) mapa[y][x] = TIPOS.AGUA;
        }
      }
      // Portal de volta
      mapa[altura-25][largura-25] = TIPOS.PORTAL;
      // Livros da floresta
      mapa[25][25] = TIPOS.LIVRO;
      mapa[40][50] = TIPOS.LIVRO;
      break;
  }
}

// ==============================================
// VERIFICAR COLISÃO COM PAREDES/OBSTÁCULOS
// ==============================================
function ehParede(x, y) {
  const blocoX = Math.floor(x / TAMANHO_BLOCO);
  const blocoY = Math.floor(y / TAMANHO_BLOCO);

  // Fora dos limites do mapa = parede
  if (blocoX < 0 || blocoX >= CONFIG_MAPA.atual.largura ||
      blocoY < 0 || blocoY >= CONFIG_MAPA.atual.altura) {
    return true;
  }

  // Retorna verdadeiro se for um bloco sólido
  const tipo = mapa[blocoY][blocoX];
  return tipo === TIPOS.PAREDE || tipo === TIPOS.AGUA;
}

// ==============================================
// SISTEMA DE PORTAL PARA OUTRAS REGIÕES
// ==============================================
function entrarPortal() {
  const blocoX = Math.floor(jogador.x / TAMANHO_BLOCO);
  const blocoY = Math.floor(jogador.y / TAMANHO_BLOCO);

  if (mapa[blocoY]?.[blocoX] !== TIPOS.PORTAL) {
    alert("❌ Não há portal neste local!");
    return;
  }

  if (jogador.sabedoria < SABEDORIA_PARA_PORTAL) {
    alert("🔒 Você precisa de pelo menos 40 pontos de sabedoria para atravessar!");
    return;
  }

  // Troca de região
  const destino = regiaoAtual === REGIOES.PRINCIPAL ? REGIOES.FLORESTA_1 : REGIOES.PRINCIPAL;
  regiaoAtual = destino;
  
  // Gera o novo mapa
  gerarMapaRegiao();
  
  // Posiciona o jogador no início da nova região
  jogador.x = 12 * TAMANHO_BLOCO;
  jogador.y = 12 * TAMANHO_BLOCO;

  alert("🌍 Você atravessou para uma nova região!");
  verificarMusica();
}

// ==============================================
// DESENHAR O MAPA NA TELA
// ==============================================
function desenharMapa() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Calcula visão do jogador (centraliza ele na tela)
  const deslocamentoX = jogador.x - canvas.width / 2;
  const deslocamentoY = jogador.y - canvas.height / 2;

  for (let y = 0; y < CONFIG_MAPA.atual.altura; y++) {
    for (let x = 0; x < CONFIG_MAPA.atual.largura; x++) {
      const tipo = mapa[y][x];
      const posX = x * TAMANHO_BLOCO - deslocamentoX;
      const posY = y * TAMANHO_BLOCO - deslocamentoY;

      // Só desenha o que está visível na tela
      if (posX + TAMANHO_BLOCO < 0 || posX > canvas.width ||
          posY + TAMANHO_BLOCO < 0 || posY > canvas.height) continue;

      // Cor de cada tipo de bloco
      switch(tipo) {
        case TIPOS.GRAMA: ctx.fillStyle = '#557733'; break;
        case TIPOS.ASFALTO: ctx.fillStyle = '#333333'; break;
        case TIPOS.CALCADA: ctx.fillStyle = '#888888'; break;
        case TIPOS.PAREDE: ctx.fillStyle = '#664422'; break;
        case TIPOS.AGUA: ctx.fillStyle = '#224488'; break;
        case TIPOS.LIVRO: ctx.fillStyle = '#FFDD44'; break;
        case TIPOS.PORTAL: ctx.fillStyle = '#9922CC'; break;
        default: ctx.fillStyle = '#557733';
      }

      ctx.fillRect(posX, posY, TAMANHO_BLOCO, TAMANHO_BLOCO);
    }
  }
}

